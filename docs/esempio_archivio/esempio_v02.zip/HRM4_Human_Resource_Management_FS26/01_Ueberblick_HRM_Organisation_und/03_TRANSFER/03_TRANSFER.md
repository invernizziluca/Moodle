---
title: "TRANSFER"
type: subsection
course: "HRM4 Human Resource Management (FS26)"
section: "1 Überblick HRM, Organisation und Strategie"
moodle_url: "http://127.0.0.1:8085/course/section.php?id=107"
moodle_id: 107
---

# TRANSFER

*Sottosezione (Unterabschnitt)* · 1 Überblick HRM, Organisation und Strategie · [Apri in Moodle](http://127.0.0.1:8085/course/section.php?id=107)

- [Einsendeaufgabe 1: HR-Strategie analysieren](01_Einsendeaufgabe_1_HR-Strategie/01_Einsendeaufgabe_1_HR-Strategie.md) — Compito (Aufgabe) · Analysieren Sie die HR-Strategie Ihres Unternehmens anhand der Kriterien aus Thema 1.
- [Thema 2: Organisationsformen im HR – Unterlagen](02_Thema_2_Organisationsformen_im_HR/02_Thema_2_Organisationsformen_im_HR.md) — Cartella (Verzeichnis) · Vorlagen und Beispiele.
